package com.example.france_app

import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class CreateAccount : AppCompatActivity() {

    private  var etFirstNam: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)
    }
}
